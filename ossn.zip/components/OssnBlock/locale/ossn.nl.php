<?php
/**
 * Open Source Social Network
 *
 * @package   (softlab24.com).ossn
 * @author    Dieter <info@marohn.nl>
 * @copyright 2014-2018 SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
$nl = array(
    'user:blocked' => 'Gebruiker is geblokkeerd!',
    'user:block:error' => 'Kon gebruiker niet blokkeren! probeer het later opnieuw.',
    'user:block' => 'Blokkeren',
    'user:unblock' => 'De-blokkeren',
	'user:unblocked' => 'Gebruiker is gedeblokkeerd',
	'user:unblock:error' => 'Kan deze gebruiker niet deblokkeren',
	'ossn:blocked:error' => 'Geblokkeerd',
	'ossn:blocked:error:note' => 'Je kan deze pagina niet bekijken omdat je door deze gebruiker geblokkeerd bent',
);
ossn_register_languages('nl', $nl); 
