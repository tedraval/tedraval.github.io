<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network
 * @author    Open Social Website Core Team <info@softlab24.com>
 * @copyright (C) SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
$el = array(
    'user:blocked' => 'Ο χρήστης έχει αποκλειστεί!',
    'user:block:error' => 'Δεν είναι δυνατός ο αποκλεισμός του χρήστη! Παρακαλώ δοκιμάστε ξανά αργότερα.',
    'user:block' => 'Αποκλεισμός',
    'user:unblock' => 'Αφαίρεση αποκλεισμού',
    'user:unblocked' => 'Ο χρήστης έχει αφαιρεθεί απο τον αποκλεισμό',
    'user:unblock:error' => 'Δεν είναι δυνατή η αφαίρεση του αποκλεισμού',
    'ossn:blocked:error' => 'Αποκλεισμένος',
    'ossn:blocked:error:note' => 'Δεν μπορείτε να δείτε αυτήν τη σελίδα επειδή έχετε μπλοκαριστεί από το χρήστη.',
);
ossn_register_languages('el', $el); 